export interface ModuleDets
{
    moduleName:any;
    courseId:any;
    
    
}