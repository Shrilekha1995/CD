export interface AddressDets
{
    id:any;
    addressLineOne:any;
    addressLineTwo:any;
    city:any;
    state:any;
    country:any;
    postalCode:any;
    userId:any;
    
}