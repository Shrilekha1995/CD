export interface ScheduleDets
{
    id:any;
    date:any;
    subject1Id:any;
    type1:any;
    from1:any;
    to1:any;
    teacherId1:any;
    subject2Id:any;
    type2:any;
    from2:any;
    to2:any;
    teacherId2:any;
    courseId:any;
    roomId:any
}